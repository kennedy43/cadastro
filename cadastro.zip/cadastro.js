const confirmar = document.getElementById("confirmar");

function confirma() {
      const nome = (document.getElementById("nome")).value;
      const nomeempresa = (document.getElementById("nomeempresa")).value;
      const nomepersonagem = (document.getElementById("nomepersonagem")).value;
      const data = (document.getElementById("data")).value;
      const precovenda = (document.getElementById("precovenda")).value;
      const precocompra = (document.getElementById("precocompra")).value;
      if (nome || nomeempresa || nomepersonagem == "") {
            alert("0");
            alert("Campo em branco!");
            if (nome == "") {
                  document.getElementById("nome").focus();
            } else {
                  if (nomeempresa == "") {
                        document.getElementById("nomeempresa").focus();
                  } else {
                        if (nomepersonagem == "") {
                              document.getElementById("nomepersonagem").focus();
                        }
                  }
            }
      }else {
            if (data == "") {
                  alert("Por favor, Insira um data");
                  document.getElementById("data").focus();
            } else {
                  if (precovenda || precocompra == "") {
                        alert("Por favor,Insira um Preço");
                        if (precovenda == "") {
                              document.getElementById("precovenda").focus();
                        } else {
                              document.getElementById("precocompra").focus();
                        }
                  }
            }
      }

}

confirmar.addEventListener("click", confirma);